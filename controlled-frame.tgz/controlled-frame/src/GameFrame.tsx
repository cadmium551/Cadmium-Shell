import { useEffect, useRef } from 'react';
import type { ControlledFrameElement } from './controlled-frame';

interface GameFrameProps {
  src: string;
  /** Storage partition. Use a `persist:` name so saves survive restarts. */
  partition: string;
  className?: string;
  /** Called with the live element once it is attached, and with null when it goes away. */
  onFrame?: (frame: ControlledFrameElement | null) => void;
}

/**
 * Renders a <controlledframe> — an IWA-only element that embeds web content as its
 * own top-level page, so the content keeps its own CSP, <base>, inline scripts etc.
 *
 * The element is created imperatively because `partition` must be set before `src`
 * (the setter throws once the frame has navigated).
 */
export default function GameFrame({ src, partition, className, onFrame }: GameFrameProps) {
  const hostRef = useRef<HTMLDivElement>(null);
  const onFrameRef = useRef(onFrame);
  onFrameRef.current = onFrame;

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    const frame = document.createElement('controlledframe') as ControlledFrameElement;
    frame.style.cssText = 'display:block;width:100%;height:100%;border:0;background:#000';
    frame.partition = partition;

    // Games must not be able to spawn windows we then have to manage.
    frame.addEventListener('newwindow', (e: any) => {
      try { e.newWindow?.window?.discard?.(); } catch { /* nothing to discard */ }
    });

    // Only the permissions a game plausibly needs. Everything else is refused.
    const allowed = new Set(['fullscreen', 'pointerLock']);
    frame.addEventListener('permissionrequest', (e: any) => {
      const req = e.permissionRequest;
      if (!req) return;
      if (allowed.has(req.permission)) req.request.allow();
      else req.request.cancel();
    });

    // alert/confirm/prompt in the game are answered with the shell's own dialogs.
    frame.addEventListener('dialog', (e: any) => {
      const m = e.dialogMessage;
      if (!m) return;
      const { dialog, messageType, messageText } = m;
      if (messageType === 'alert') { window.alert(messageText); dialog.okay(); }
      else if (messageType === 'confirm') { window.confirm(messageText) ? dialog.okay() : dialog.cancel(); }
      else {
        const answer = window.prompt(messageText);
        if (answer === null) dialog.cancel(); else dialog.okay(answer);
      }
    });

    host.appendChild(frame);
    frame.src = src; // after partition, after insertion
    onFrameRef.current?.(frame);

    return () => {
      onFrameRef.current?.(null);
      frame.remove();
    };
  }, [src, partition]);

  return <div ref={hostRef} className={className} />;
}
