/**
 * Local HTTP server for imported games.
 *
 * A Controlled Frame loads real URLs, so imported (OPFS) games need something to
 * serve them. This runs a tiny HTTP/1.1 server inside the IWA using Direct Sockets'
 * TCPServerSocket and answers from OPFS (cadmium_games/<id>/www/...).
 *
 * Each game gets its own origin — http://<label>.localhost:<port>/ — so games
 * can use root-absolute URLs and cannot read each other's storage.
 *
 * Requires "direct-sockets" (and "direct-sockets-private") in the manifest's
 * permissions_policy.
 */

const encoder = new TextEncoder();
const decoder = new TextDecoder();

// ─── Protocol layer (no browser-only APIs; unit-testable under Node) ──────────

export type FileResolver = (host: string, pathname: string) => Promise<File | null>;

export interface ServeOptions {
  /**
   * Send COOP/COEP so games can use SharedArrayBuffer (threaded Unity builds etc).
   * Off by default: COEP can break third-party iframes and some CDN assets.
   */
  crossOriginIsolate?: boolean;
}

const MIME: Record<string, string> = {
  html: 'text/html; charset=utf-8', htm: 'text/html; charset=utf-8',
  js: 'text/javascript', mjs: 'text/javascript', css: 'text/css',
  json: 'application/json', map: 'application/json', webmanifest: 'application/manifest+json',
  wasm: 'application/wasm', xml: 'application/xml', txt: 'text/plain; charset=utf-8',
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif',
  webp: 'image/webp', svg: 'image/svg+xml', ico: 'image/x-icon', bmp: 'image/bmp',
  mp3: 'audio/mpeg', ogg: 'audio/ogg', wav: 'audio/wav', m4a: 'audio/mp4', flac: 'audio/flac',
  mp4: 'video/mp4', webm: 'video/webm',
  woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', otf: 'font/otf',
};

/** Content type for a file name; `.br` / `.gz` get Content-Encoding (Unity convention). */
function describeFile(name: string): { type: string; encoding?: string } {
  let n = name.toLowerCase();
  let encoding: string | undefined;
  if (n.endsWith('.br')) { encoding = 'br'; n = n.slice(0, -3); }
  else if (n.endsWith('.gz')) { encoding = 'gzip'; n = n.slice(0, -3); }
  const ext = n.includes('.') ? n.slice(n.lastIndexOf('.') + 1) : '';
  return { type: MIME[ext] ?? 'application/octet-stream', encoding };
}

function indexOfHeaderEnd(buf: Uint8Array): number {
  for (let i = 0; i + 3 < buf.length; i++) {
    if (buf[i] === 13 && buf[i + 1] === 10 && buf[i + 2] === 13 && buf[i + 3] === 10) return i;
  }
  return -1;
}

class ByteReader {
  private buf: Uint8Array = new Uint8Array(0);
  private reader: ReadableStreamDefaultReader<Uint8Array>;

  constructor(readable: ReadableStream<Uint8Array>) {
    this.reader = readable.getReader();
  }

  private append(chunk: Uint8Array) {
    const next = new Uint8Array(this.buf.length + chunk.length);
    next.set(this.buf);
    next.set(chunk, this.buf.length);
    this.buf = next;
  }

  /** Reads one request head (up to the blank line). Null when the peer closed. */
  async readHead(): Promise<string | null> {
    for (;;) {
      const end = indexOfHeaderEnd(this.buf);
      if (end >= 0) {
        const head = decoder.decode(this.buf.subarray(0, end));
        this.buf = this.buf.slice(end + 4);
        return head;
      }
      if (this.buf.length > 65536) throw new Error('Request header too large');
      const { value, done } = await this.reader.read();
      if (done) return null;
      this.append(value);
    }
  }

  /** Discards a request body we do not use. */
  async skip(n: number) {
    while (n > 0) {
      if (this.buf.length === 0) {
        const { value, done } = await this.reader.read();
        if (done) return;
        this.append(value);
      }
      const take = Math.min(n, this.buf.length);
      this.buf = this.buf.slice(take);
      n -= take;
    }
  }

  release() {
    try { this.reader.releaseLock(); } catch { /* already released */ }
  }
}

const STATUS_TEXT: Record<number, string> = {
  200: 'OK', 206: 'Partial Content', 400: 'Bad Request', 404: 'Not Found',
  405: 'Method Not Allowed', 416: 'Range Not Satisfiable', 431: 'Request Header Fields Too Large',
  500: 'Internal Server Error',
};

/**
 * Serves HTTP/1.1 requests (GET/HEAD, keep-alive, byte ranges) on one connection
 * until the peer closes or sends `Connection: close`.
 */
export async function serveConnection(
  readable: ReadableStream<Uint8Array>,
  writable: WritableStream<Uint8Array>,
  resolve: FileResolver,
  options: ServeOptions = {},
): Promise<void> {
  const input = new ByteReader(readable);
  const writer = writable.getWriter();

  const commonHeaders = (): Record<string, string> => {
    const h: Record<string, string> = {
      'Server': 'CadmiumShell',
      'Cache-Control': 'no-cache',
      'Access-Control-Allow-Origin': '*',
      'Cross-Origin-Resource-Policy': 'cross-origin',
    };
    if (options.crossOriginIsolate) {
      h['Cross-Origin-Opener-Policy'] = 'same-origin';
      h['Cross-Origin-Embedder-Policy'] = 'credentialless';
    }
    return h;
  };

  const writeHead = async (status: number, headers: Record<string, string | number>) => {
    let head = `HTTP/1.1 ${status} ${STATUS_TEXT[status] ?? 'OK'}\r\n`;
    for (const [k, v] of Object.entries(headers)) head += `${k}: ${v}\r\n`;
    await writer.write(encoder.encode(head + '\r\n'));
  };

  const sendText = async (status: number, text: string, keepAlive: boolean, extra: Record<string, string> = {}) => {
    const body = encoder.encode(text);
    await writeHead(status, {
      ...commonHeaders(), ...extra,
      'Content-Type': 'text/plain; charset=utf-8',
      'Content-Length': body.length,
      'Connection': keepAlive ? 'keep-alive' : 'close',
    });
    await writer.write(body);
  };

  try {
    for (;;) {
      let head: string | null;
      try {
        head = await input.readHead();
      } catch {
        await sendText(431, 'Request header too large', false);
        return;
      }
      if (head === null) return;

      const lines = head.split('\r\n');
      const [method, target, version] = lines[0].split(' ');
      const headers: Record<string, string> = {};
      for (const line of lines.slice(1)) {
        const i = line.indexOf(':');
        if (i > 0) headers[line.slice(0, i).trim().toLowerCase()] = line.slice(i + 1).trim();
      }

      const connection = (headers['connection'] ?? '').toLowerCase();
      const keepAlive = version === 'HTTP/1.1' ? connection !== 'close' : connection === 'keep-alive';

      if (headers['transfer-encoding']) { await sendText(400, 'Chunked requests are not supported', false); return; }
      const bodyLen = parseInt(headers['content-length'] ?? '0', 10) || 0;
      if (bodyLen > 0) await input.skip(bodyLen);

      if (method !== 'GET' && method !== 'HEAD') {
        await sendText(405, 'Method not allowed', false, { 'Allow': 'GET, HEAD' });
        return;
      }

      let pathname: string;
      try {
        pathname = decodeURIComponent(new URL(target ?? '/', 'http://localhost').pathname);
      } catch {
        await sendText(400, 'Bad request path', keepAlive);
        if (!keepAlive) return;
        continue;
      }
      if (pathname.includes('\0') || pathname.includes('\\') || pathname.split('/').some(s => s === '..')) {
        await sendText(400, 'Bad request path', keepAlive);
        if (!keepAlive) return;
        continue;
      }

      let file: File | null = null;
      try {
        file = await resolve(headers['host'] ?? '', pathname);
      } catch {
        file = null;
      }
      if (!file) {
        await sendText(404, `Not found: ${pathname}`, keepAlive);
        if (!keepAlive) return;
        continue;
      }

      const size = file.size;
      let status = 200;
      let start = 0;
      let end = size - 1;
      const range = headers['range'];
      if (range) {
        const m = /^bytes=(\d*)-(\d*)$/.exec(range.trim());
        if (m && (m[1] !== '' || m[2] !== '')) {
          if (m[1] === '') {
            start = Math.max(0, size - parseInt(m[2], 10));
          } else {
            start = parseInt(m[1], 10);
            end = m[2] === '' ? size - 1 : Math.min(parseInt(m[2], 10), size - 1);
          }
          if (start > end || start >= size) {
            await sendText(416, 'Range not satisfiable', keepAlive, { 'Content-Range': `bytes */${size}` });
            if (!keepAlive) return;
            continue;
          }
          status = 206;
        }
      }

      const { type, encoding } = describeFile(file.name);
      const length = size === 0 ? 0 : end - start + 1;
      const out: Record<string, string | number> = {
        ...commonHeaders(),
        'Content-Type': type,
        'Content-Length': length,
        'Accept-Ranges': 'bytes',
        'Last-Modified': new Date(file.lastModified).toUTCString(),
        'Connection': keepAlive ? 'keep-alive' : 'close',
      };
      if (encoding) out['Content-Encoding'] = encoding;
      if (status === 206) out['Content-Range'] = `bytes ${start}-${end}/${size}`;
      await writeHead(status, out);

      if (method === 'GET' && length > 0) {
        const body = file.slice(start, end + 1).stream().getReader();
        for (;;) {
          const { value, done } = await body.read();
          if (done) break;
          await writer.write(value);
        }
      }

      if (!keepAlive) return;
    }
  } finally {
    input.release();
    try { writer.releaseLock(); } catch { /* already released */ }
  }
}

// ─── Server (browser only) ────────────────────────────────────────────────────

/** Fixed ports keep each game's origin — and therefore its saves — stable between runs. */
const PORTS = [47831, 47832, 47833, 47834, 47835, 47836, 47837, 47838];
const BIND_ADDRESSES = ['127.0.0.1', '::1'];

const fnv1a = (s: string): string => {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return (h >>> 0).toString(16).padStart(8, '0');
};

/** DNS-safe label for a game id: readable prefix + hash so different ids never collide. */
export const hostLabelFor = (gameId: string): string => {
  const slug = gameId.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'game';
  return `${slug}-${fnv1a(gameId).slice(0, 6)}`;
};

/** Storage partition name for a game (alphanumeric, persistent). */
export const partitionFor = (gameId: string): string =>
  `persist:cadmium${hostLabelFor(gameId).replace(/[^a-z0-9]/g, '')}`;

export const directSocketsSupported = (): boolean =>
  typeof (globalThis as any).TCPServerSocket === 'function';

export class GameServer {
  port = 0;
  address = '';
  private socket: any = null;
  private starting: Promise<number> | null = null;
  private labels = new Map<string, string>();
  private wwwDirs = new Map<string, FileSystemDirectoryHandle>();

  constructor(private options: ServeOptions = {}) {}

  /** Starts listening (idempotent). Resolves with the port in use. */
  start(): Promise<number> {
    if (this.port) return Promise.resolve(this.port);
    if (!this.starting) {
      this.starting = this.open().finally(() => { this.starting = null; });
    }
    return this.starting;
  }

  private async open(): Promise<number> {
    if (!directSocketsSupported()) {
      throw new Error('Direct Sockets (TCPServerSocket) is not available. It needs the installed IWA with the "direct-sockets" permission.');
    }
    const Server = (globalThis as any).TCPServerSocket;
    let lastError: unknown;
    for (const port of PORTS) {
      for (const address of BIND_ADDRESSES) {
        try {
          const socket = new Server(address, { localPort: port, backlog: 64 });
          const info = await socket.opened;
          this.socket = socket;
          this.address = address;
          this.port = info.localPort ?? port;
          void this.acceptLoop(info.readable);
          if (port !== PORTS[0]) {
            console.warn(`[Cadmium] Preferred port ${PORTS[0]} was busy; using ${this.port}. Game saves are tied to the port, so existing saves may not appear.`);
          }
          console.log(`[Cadmium] Game server listening on ${address}:${this.port}`);
          return this.port;
        } catch (err) {
          lastError = err;
        }
      }
    }
    throw new Error(`Could not start the local game server: ${(lastError as Error)?.message ?? lastError}`);
  }

  /** Registers a game and returns the URL its Controlled Frame should load. */
  register(gameId: string): string {
    if (!this.port) throw new Error('Game server is not running');
    const label = hostLabelFor(gameId);
    this.labels.set(label, gameId);
    return `http://${label}.localhost:${this.port}/`;
  }

  async stop() {
    try { await this.socket?.close(); } catch { /* already closed */ }
    this.socket = null;
    this.port = 0;
    this.wwwDirs.clear();
  }

  private async acceptLoop(readable: ReadableStream<any>) {
    const reader = readable.getReader();
    try {
      for (;;) {
        const { value: socket, done } = await reader.read();
        if (done) break;
        void this.handle(socket);
      }
    } catch (err) {
      console.error('[Cadmium] Game server accept loop ended:', err);
    }
  }

  private async handle(socket: any) {
    try {
      const { readable, writable } = await socket.opened;
      await serveConnection(readable, writable, (host, path) => this.resolve(host, path), this.options);
    } catch {
      // connection reset / aborted by the frame — nothing to do
    } finally {
      try { await socket.close(); } catch { /* already closed */ }
    }
  }

  private async wwwDir(gameId: string): Promise<FileSystemDirectoryHandle> {
    let dir = this.wwwDirs.get(gameId);
    if (!dir) {
      const root = await navigator.storage.getDirectory();
      const games = await root.getDirectoryHandle('cadmium_games');
      const game = await games.getDirectoryHandle(gameId);
      dir = await game.getDirectoryHandle('www');
      this.wwwDirs.set(gameId, dir);
    }
    return dir;
  }

  private resolve = async (host: string, pathname: string): Promise<File | null> => {
    const label = host.split(':')[0].replace(/\.localhost$/, '');
    const gameId = this.labels.get(label);
    if (!gameId) return null;
    try {
      let dir = await this.wwwDir(gameId);
      const parts = pathname.split('/').filter(Boolean);
      if (pathname.endsWith('/') || parts.length === 0) parts.push('index.html');
      for (let i = 0; i < parts.length - 1; i++) dir = await dir.getDirectoryHandle(parts[i]);
      const last = parts[parts.length - 1];
      try {
        return await (await dir.getFileHandle(last)).getFile();
      } catch {
        // a directory requested without a trailing slash
        const sub = await dir.getDirectoryHandle(last);
        return await (await sub.getFileHandle('index.html')).getFile();
      }
    } catch {
      return null;
    }
  };
}
