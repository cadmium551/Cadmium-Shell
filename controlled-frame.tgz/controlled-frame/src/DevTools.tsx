import React, { useState, useEffect, useRef, useCallback } from 'react';
import { X, Terminal, Radio, Wifi, Database, Trash2, Folder, File, CornerUpLeft, HardDrive, ArrowUp } from 'lucide-react';
import type { ControlledFrameElement } from './controlled-frame';

// ─── Types ────────────────────────────────────────────────────────────────────

type LogLevel = 'log' | 'warn' | 'error' | 'info';
type LogSource = 'shell' | 'game';

interface LogEntry {
  id: number;
  level: LogLevel;
  source: LogSource;
  msg: string;
  time: string;
}

interface MsgEntry {
  id: number;
  dir: 'shell→game' | 'game→shell';
  type: string;
  payload: string;
  time: string;
}

interface NetEntry {
  id: number;
  method: string;
  url: string;
  status: number | 'ERR' | '…' | '(navigated)';
  type: string;
  size: string;
  dur: string;
  time: string;
}

type Tab = 'console' | 'messages' | 'network' | 'storage' | 'opfs';
type StorageTab = 'local' | 'session' | 'cookies';

interface OpfsEntry {
  name: string;
  kind: 'file' | 'directory';
  handle: any;
  size?: number;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

let _id = 0;
const uid = () => ++_id;

const ts = () => {
  const d = new Date();
  return [d.getHours(), d.getMinutes(), d.getSeconds()]
    .map(n => n.toString().padStart(2, '0'))
    .join(':');
};

const serialize = (v: unknown): string => {
  if (v === null) return 'null';
  if (v === undefined) return 'undefined';
  if (typeof v === 'object') {
    try { return JSON.stringify(v, null, 2); } catch { return String(v); }
  }
  return String(v);
};

const formatBytes = (b: number): string => {
  if (b < 1024) return b + 'B';
  if (b < 1048576) return (b / 1024).toFixed(1) + 'KB';
  return (b / 1048576).toFixed(1) + 'MB';
};

// ─── Main Component ───────────────────────────────────────────────────────────

interface DevToolsProps {
  frame: ControlledFrameElement | null;
  activeGame: string | null;
  onClose: () => void;
}

export default function DevTools({ frame, activeGame, onClose }: DevToolsProps) {
  const [tab, setTab] = useState<Tab>('console');
  const [storeTab, setStoreTab] = useState<StorageTab>('local');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [msgs, setMsgs] = useState<MsgEntry[]>([]);
  const [nets, setNets] = useState<NetEntry[]>([]);
  const [storeData, setStoreData] = useState<[string, string][]>([]);
  
  // OPFS State
  const [opfsStack, setOpfsStack] = useState<{name: string, handle: any}[]>([]);
  const [opfsEntries, setOpfsEntries] = useState<OpfsEntry[]>([]);
  const currentOpfsHandleRef = useRef<any>(null);

  const [filter, setFilter] = useState('');
  const [levelFilter, setLevelFilter] = useState<LogLevel | 'all'>('all');
  const [consoleInput, setConsoleInput] = useState('');
  const [height, setHeight] = useState(320);
  const [dragging, setDragging] = useState(false);
  const dragStartY = useRef(0);
  const dragStartH = useRef(0);
  const logEndRef = useRef<HTMLDivElement>(null);
  const patchedRef = useRef(false);
  const origConsole = useRef<Record<string, (...args: unknown[]) => void>>({});

  // ─── Console interception (shell scope) ───────────────────────────────────

  const addLog = useCallback((level: LogLevel, source: LogSource, args: unknown[]) => {
    const msg = args.map(serialize).join(' ');
    setLogs(prev => [...prev.slice(-499), { id: uid(), level, source, msg, time: ts() }]);
  }, []);

  useEffect(() => {
    if (patchedRef.current) return;
    patchedRef.current = true;

    (['log', 'warn', 'error', 'info'] as LogLevel[]).forEach(m => {
      origConsole.current[m] = (console[m] as (...args: unknown[]) => void).bind(console);
      (console as unknown as Record<string, (...args: unknown[]) => void>)[m] = (...args: unknown[]) => {
        origConsole.current[m](...args);
        addLog(m, 'shell', args);
      };
    });

    const onError = (e: ErrorEvent) =>
      addLog('error', 'shell', [`${e.message} (${e.filename}:${e.lineno})`]);
    const onReject = (e: PromiseRejectionEvent) =>
      addLog('error', 'shell', ['Unhandled rejection: ' + e.reason]);

    window.addEventListener('error', onError);
    window.addEventListener('unhandledrejection', onReject);

    return () => {
      window.removeEventListener('error', onError);
      window.removeEventListener('unhandledrejection', onReject);
    };
  }, [addLog]);

  // ─── Game console relay (Controlled Frame "consolemessage") ───────────────
  // The game is a separate top-level page, so its console can't be patched from
  // here. The Controlled Frame reports every console message as an event instead.

  useEffect(() => {
    if (!frame) return;
    const levels: LogLevel[] = ['log', 'info', 'warn', 'error'];
    const onConsole = (e: any) => {
      const cm = e.consoleMessage ?? e;
      const level = typeof cm.level === 'number' ? (levels[cm.level] ?? 'log') : 'log';
      addLog(level, 'game', [cm.message]);
    };
    frame.addEventListener('consolemessage', onConsole);
    return () => frame.removeEventListener('consolemessage', onConsole);
  }, [frame, addLog]);

  // ─── postMessage monitoring ───────────────────────────────────────────────

  useEffect(() => {
    const handler = (e: MessageEvent) => {
      if (e.data?.__cdvt) {
        addLog(e.data.level as LogLevel, 'game', e.data.args);
        return;
      }
      if (!e.data || typeof e.data !== 'object') return;
      const dir = frame && e.source === frame.contentWindow
        ? 'game→shell' as const
        : 'shell→game' as const;
      const type = e.data.type ?? '(no type)';
      let payload = '';
      try { payload = JSON.stringify(e.data, null, 2); } catch { payload = String(e.data); }
      setMsgs(prev => [...prev.slice(-199), { id: uid(), dir, type, payload, time: ts() }]);
    };
    window.addEventListener('message', handler);
    return () => window.removeEventListener('message', handler);
  }, [addLog, frame]);

  // ─── Network interception ─────────────────────────────────────────────────
  // Covers window.fetch() and XHR from the shell's own scope. This CANNOT see
  // the game iframe's navigation load or its own internal requests — those
  // are covered separately below, via the Service Worker broadcast and the
  // iframe's load event, since nothing in the parent page's JS is ever in
  // the path for a cross-document navigation.

  useEffect(() => {
    const origFetch = window.fetch;
    window.fetch = function (input: RequestInfo | URL, init?: RequestInit) {
      const url = typeof input === 'string' ? input : input instanceof URL ? input.href : (input as Request).url;
      const method = init?.method ?? (typeof input !== 'string' && !(input instanceof URL) ? (input as Request).method : 'GET');
      const start = Date.now();
      const entry: NetEntry = { id: uid(), method, url, status: '…', type: 'fetch', size: '-', dur: '-', time: ts() };
      setNets(prev => [...prev.slice(-99), entry]);

      return origFetch(input, init)
        .then(res => {
          const len = res.headers.get('content-length');
          setNets(prev => prev.map(n => n.id === entry.id
            ? { ...n, status: res.status, size: len ? formatBytes(+len) : '-', dur: (Date.now() - start) + 'ms' }
            : n));
          return res;
        })
        .catch(err => {
          setNets(prev => prev.map(n => n.id === entry.id
            ? { ...n, status: 'ERR', dur: (Date.now() - start) + 'ms' }
            : n));
          throw err;
        });
    };

    const OrigXHR = window.XMLHttpRequest;
    class PatchedXHR extends OrigXHR {
      private _cdvtEntryId?: number;
      private _cdvtMethod = 'GET';
      private _cdvtUrl = '';
      private _cdvtStart = 0;

      open(method: string, url: string | URL, ...rest: unknown[]) {
        this._cdvtMethod = method;
        this._cdvtUrl = typeof url === 'string' ? url : url.href;
        // @ts-expect-error - forwarding variadic XHR.open args
        return super.open(method, url, ...rest);
      }
      send(...args: unknown[]) {
        this._cdvtStart = Date.now();
        const id = uid();
        this._cdvtEntryId = id;
        setNets(prev => [...prev.slice(-99), {
          id, method: this._cdvtMethod, url: this._cdvtUrl, status: '…', type: 'xhr', size: '-', dur: '-', time: ts(),
        }]);
        this.addEventListener('loadend', () => {
          const len = this.getResponseHeader('content-length');
          setNets(prev => prev.map(n => n.id === id
            ? {
                ...n,
                status: this.status || 'ERR',
                size: len ? formatBytes(+len) : '-',
                dur: (Date.now() - this._cdvtStart) + 'ms',
              }
            : n));
        });
        // @ts-expect-error - forwarding variadic XHR.send args
        return super.send(...args);
      }
    }
    window.XMLHttpRequest = PatchedXHR as unknown as typeof XMLHttpRequest;

    return () => {
      window.fetch = origFetch;
      window.XMLHttpRequest = OrigXHR;
    };
  }, []);

  // ─── Service Worker network relay (catches iframe navigations) ───────────
  // The SW broadcasts every /vfs/ request it actually handles. If a game
  // launch never produces an entry here, the request never reached the SW
  // at all — that's the key signal for diagnosing a connection-level failure
  // rather than an in-app 404/error response (which WOULD show up here).

  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    const handler = (event: MessageEvent) => {
      const d = event.data;
      if (!d?.__cdvtNet) return;
      setNets(prev => [...prev.slice(-99), {
        id: uid(),
        method: d.method,
        url: d.url,
        status: d.status,
        type: d.error ? `sw:${d.navigation ? 'nav' : 'sub'} err` : `sw:${d.navigation ? 'nav' : 'sub'}`,
        size: '-',
        dur: `${d.dur}ms`,
        time: ts(),
      }]);
      if (d.error) addLog('error', 'shell', [`[SW] ${d.method} ${d.url} failed: ${d.error}`]);
    };
    navigator.serviceWorker.addEventListener('message', handler);
    return () => navigator.serviceWorker.removeEventListener('message', handler);
  }, [addLog]);

  // ─── Game network + navigation (Controlled Frame) ─────────────────────────
  // loadcommit marks each page the frame lands on. The WebRequest interceptor
  // lists the game's own requests; it is best-effort (the event shapes come from
  // the Controlled Frame spec) and fails soft.

  useEffect(() => {
    if (!frame) return;

    const onCommit = (e: any) => {
      const url = e.loadInfo?.url ?? e.url ?? frame.src;
      setNets(prev => [...prev.slice(-99), {
        id: uid(), method: 'GET', url, status: '(navigated)', type: 'frame-load', size: '-', dur: '-', time: ts(),
      }]);
    };
    frame.addEventListener('loadcommit', onCommit);

    const onAbort = (e: any) => {
      const info = e.loadAbortInfo ?? e;
      addLog('error', 'shell', [`[frame] load aborted: ${info.url ?? ''} ${info.reason ?? ''}`.trim()]);
    };
    frame.addEventListener('loadabort', onAbort);

    try {
      const interceptor = frame.request.createWebRequestInterceptor({ urlPatterns: ['*://*/*'], blocking: false });
      interceptor.addEventListener('beforerequest', (e: any) => {
        const req = e.request ?? e;
        setNets(prev => [...prev.slice(-99), {
          id: uid(), method: req.method ?? 'GET', url: req.url ?? e.url ?? '?', status: '…',
          type: req.type ?? req.resourceType ?? 'game', size: '-', dur: '-', time: ts(),
        }]);
      });
    } catch (err) {
      addLog('warn', 'shell', ['[frame] request interception unavailable: ' + (err as Error).message]);
    }

    return () => {
      frame.removeEventListener('loadcommit', onCommit);
      frame.removeEventListener('loadabort', onAbort);
    };
  }, [frame, addLog]);

  // ─── OPFS Reader ──────────────────────────────────────────────────────────

  const loadOpfsDir = useCallback(async (handle?: any) => {
    try {
      const dirHandle = handle || await (navigator.storage as any).getDirectory();
      currentOpfsHandleRef.current = dirHandle;
      const entries: OpfsEntry[] = [];
      const iterator = dirHandle.values();
      
      for await (const entryHandle of iterator) {
        let size = undefined;
        if (entryHandle.kind === 'file') {
          const file = await entryHandle.getFile();
          size = file.size;
        }
        entries.push({ name: entryHandle.name, kind: entryHandle.kind, handle: entryHandle, size });
      }

      entries.sort((a, b) => {
        if (a.kind === b.kind) return a.name.localeCompare(b.name);
        return a.kind === 'directory' ? -1 : 1;
      });
      setOpfsEntries(entries);
    } catch (err) {
      addLog('error', 'shell', ['OPFS Read Error: ' + String(err)]);
    }
  }, [addLog]);

  const enterOpfsDir = (name: string, handle: any) => {
    setOpfsStack(prev => [...prev, { name, handle }]);
    loadOpfsDir(handle);
  };

  const popOpfsDir = () => {
    setOpfsStack(prev => {
      const next = prev.slice(0, -1);
      const parentHandle = next.length > 0 ? next[next.length - 1].handle : undefined;
      loadOpfsDir(parentHandle);
      return next;
    });
  };

  const dumpOpfsFile = async (handle: any) => {
    try {
      const file = await handle.getFile();
      const text = await file.text();
      addLog('info', 'shell', [`[OPFS] Content of "${file.name}" (${formatBytes(file.size)}):`, text]);
      setTab('console');
    } catch (err) {
      addLog('error', 'shell', ['OPFS Read File Error (File might be binary): ' + String(err)]);
    }
  };

  // ─── Storage reader ───────────────────────────────────────────────────────

  const readStorage = useCallback((mode: StorageTab) => {
    const items: [string, string][] = [];
    try {
      if (mode === 'local') {
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i)!;
          items.push([k, localStorage.getItem(k) ?? '']);
        }
      } else if (mode === 'session') {
        for (let i = 0; i < sessionStorage.length; i++) {
          const k = sessionStorage.key(i)!;
          items.push([k, sessionStorage.getItem(k) ?? '']);
        }
      } else {
        document.cookie.split(';').forEach(c => {
          const [k, ...rest] = c.trim().split('=');
          if (k) items.push([k, rest.join('=')]);
        });
      }
    } catch { /* blocked */ }
    setStoreData(items);
  }, []);

  useEffect(() => {
    if (tab === 'storage') {
      readStorage(storeTab);
    } else if (tab === 'opfs') {
      loadOpfsDir(currentOpfsHandleRef.current);
    }
  }, [tab, storeTab, readStorage, loadOpfsDir]);

  // ─── Scroll to bottom on new logs ────────────────────────────────────────

  useEffect(() => {
    if (tab === 'console') logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs, tab]);

  // ─── Drag-to-resize ───────────────────────────────────────────────────────

  const onDragStart = (e: React.MouseEvent) => {
    e.preventDefault();
    setDragging(true);
    dragStartY.current = e.clientY;
    dragStartH.current = height;
  };

  useEffect(() => {
    if (!dragging) return;
    const onMove = (e: MouseEvent) => {
      const delta = dragStartY.current - e.clientY;
      setHeight(Math.max(180, Math.min(window.innerHeight * 0.8, dragStartH.current + delta)));
    };
    const onUp = () => setDragging(false);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, [dragging]);

  // ─── Eval expression ─────────────────────────────────────────────────────

  const runExpr = async () => {
    const expr = consoleInput.trim();
    if (!expr) return;
    setConsoleInput('');
    addLog('log', 'shell', ['> ' + expr]);
    if (!frame) {
      addLog('error', 'shell', ['No game is running.']);
      return;
    }
    try {
      // Runs in the game frame's isolated world: it sees the page's DOM but not its JS variables.
      const result = await frame.executeScript({ code: expr });
      if (result !== undefined) addLog('log', 'game', [result]);
    } catch (err) {
      addLog('error', 'game', [String((err as Error)?.message ?? err)]);
    }
  };

  const visibleLogs = logs.filter(l => {
    if (levelFilter !== 'all' && l.level !== levelFilter) return false;
    if (filter && !l.msg.toLowerCase().includes(filter.toLowerCase())) return false;
    return true;
  });

  const clearTab = () => {
    if (tab === 'console') setLogs([]);
    else if (tab === 'messages') setMsgs([]);
    else if (tab === 'network') setNets([]);
  };

  // ─── Render ───────────────────────────────────────────────────────────────

  const tabs: { key: Tab; label: string; icon: React.ReactNode; count?: number }[] = [
    { key: 'console', label: 'Console', icon: <Terminal size={13} />, count: logs.filter(l => l.level === 'error').length || undefined },
    { key: 'messages', label: 'Messages', icon: <Radio size={13} />, count: msgs.length || undefined },
    { key: 'network', label: 'Network', icon: <Wifi size={13} />, count: nets.length || undefined },
    { key: 'storage', label: 'Storage', icon: <Database size={13} /> },
    { key: 'opfs', label: 'Files', icon: <HardDrive size={13} /> },
  ];

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-[95] flex flex-col bg-[#060606] border-t border-white/10 shadow-2xl font-mono text-white"
      style={{ height }}
    >
      {/* Drag handle */}
      <div
        onMouseDown={onDragStart}
        className="h-[5px] cursor-ns-resize flex-shrink-0 flex items-center justify-center group bg-white/5 hover:bg-cadmium-red/50 transition-colors"
        title="Drag to resize"
      />

      {/* Tab bar */}
      <div className="flex items-center border-b border-white/10 flex-shrink-0 bg-[#0a0a0a] overflow-x-auto">
        {tabs.map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-1.5 px-4 py-2 text-[10px] uppercase tracking-widest transition-all border-b-2 ${
              tab === t.key
                ? 'text-white border-cadmium-red bg-white/5'
                : 'text-white/30 border-transparent hover:text-white/60'
            }`}
          >
            {t.icon}
            {t.label}
            {t.count ? (
              <span className={`text-[9px] px-1 rounded ${t.key === 'console' ? 'bg-cadmium-red/20 text-cadmium-red' : 'bg-white/10 text-white/50'}`}>
                {t.count}
              </span>
            ) : null}
          </button>
        ))}

        <div className="ml-auto flex items-center gap-2 pr-3 shrink-0">
          {tab === 'console' && (
            <div className="flex items-center gap-1 mr-2">
              {(['all', 'log', 'warn', 'error', 'info'] as const).map(l => (
                <button
                  key={l}
                  onClick={() => setLevelFilter(l)}
                  className={`text-[9px] px-2 py-0.5 rounded uppercase tracking-wider transition-all ${
                    levelFilter === l
                      ? 'bg-cadmium-red/20 text-cadmium-red border border-cadmium-red/30'
                      : 'text-white/20 hover:text-white/50'
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>
          )}
          {tab === 'storage' && (
            <button 
              onClick={() => readStorage(storeTab)} 
              className="text-[9px] text-white/30 hover:text-white/60 uppercase tracking-widest transition-colors px-2"
            >
              Refresh
            </button>
          )}
          {tab === 'opfs' && (
            <button 
              onClick={() => loadOpfsDir(currentOpfsHandleRef.current)} 
              className="text-[9px] text-white/30 hover:text-white/60 uppercase tracking-widest transition-colors px-2"
            >
              Refresh
            </button>
          )}
          <button onClick={clearTab} title="Clear" className="p-1.5 text-white/20 hover:text-cadmium-red transition-colors">
            <Trash2 size={12} />
          </button>
          <button onClick={onClose} title="Close DevTools (F12)" className="p-1.5 text-white/20 hover:text-white transition-colors">
            <X size={14} />
          </button>
        </div>
      </div>

      {/* ─── CONSOLE ─────────────────────────────────────────────────── */}
      {tab === 'console' && (
        <div className="flex flex-col flex-1 overflow-hidden">
          <div className="flex-shrink-0 px-3 py-1.5 border-b border-white/5">
            <input
              type="text"
              value={filter}
              onChange={e => setFilter(e.target.value)}
              placeholder="Filter output..."
              className="w-full bg-transparent text-[11px] text-white/70 outline-none placeholder:text-white/20"
            />
          </div>
          <div className="flex-1 overflow-y-auto text-[11px] leading-relaxed">
            {visibleLogs.map(l => (
              <div
                key={l.id}
                className={`flex gap-2 px-3 py-1 border-b border-white/[0.03] hover:bg-white/[0.02] ${
                  l.level === 'error' ? 'bg-red-900/10' :
                  l.level === 'warn'  ? 'bg-yellow-900/10' : ''
                }`}
              >
                <span className={`flex-shrink-0 w-[34px] text-[9px] text-center rounded px-1 ${
                  l.level === 'error' ? 'text-cadmium-red bg-cadmium-red/10' :
                  l.level === 'warn'  ? 'text-yellow-400 bg-yellow-400/10' :
                  l.level === 'info'  ? 'text-blue-400 bg-blue-400/10' :
                  'text-white/20 bg-white/5'
                }`}>{l.level}</span>
                <span className={`flex-shrink-0 text-[9px] px-1 rounded ${
                  l.source === 'game' ? 'text-cadmium-red/60 bg-cadmium-red/5' : 'text-white/20 bg-white/5'
                }`}>{l.source}</span>
                <span className="flex-1 text-white/70 whitespace-pre-wrap break-all">{l.msg}</span>
                <span className="flex-shrink-0 text-white/20 text-[9px] tabular-nums">{l.time}</span>
              </div>
            ))}
            {visibleLogs.length === 0 && (
              <p className="text-white/20 text-[10px] uppercase tracking-widest text-center py-8">No output yet</p>
            )}
            <div ref={logEndRef} />
          </div>
          <div className="flex-shrink-0 flex items-center gap-2 px-3 py-2 border-t border-white/10 bg-[#0a0a0a]">
            <span className="text-cadmium-red text-[11px]">&gt;</span>
            <input
              type="text"
              value={consoleInput}
              onChange={e => setConsoleInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') runExpr(); }}
              placeholder="Run JavaScript in shell scope..."
              className="flex-1 bg-transparent text-[11px] text-white/80 outline-none placeholder:text-white/20"
            />
            <button onClick={runExpr} className="text-[9px] text-white/30 hover:text-cadmium-red uppercase tracking-widest transition-colors px-2 py-1 border border-white/10 rounded">
              Run
            </button>
          </div>
        </div>
      )}

      {/* ─── MESSAGES ────────────────────────────────────────────────── */}
      {tab === 'messages' && (
        <div className="flex-1 overflow-y-auto text-[10px]">
          {msgs.length === 0 && (
            <p className="text-white/20 uppercase tracking-widest text-center py-8">No postMessage events captured yet</p>
          )}
          {[...msgs].reverse().map(m => (
            <div key={m.id} className="border-b border-white/[0.03] hover:bg-white/[0.02] px-3 py-1.5">
              <div className="flex items-center gap-2 mb-0.5">
                <span className={`text-[9px] px-1.5 py-0.5 rounded ${
                  m.dir === 'game→shell' ? 'bg-cadmium-red/20 text-cadmium-red' : 'bg-blue-400/10 text-blue-400'
                }`}>{m.dir}</span>
                <span className="text-white/60 font-bold">{m.type}</span>
                <span className="ml-auto text-white/20 tabular-nums">{m.time}</span>
              </div>
              <pre className="text-white/30 whitespace-pre-wrap break-all text-[9px] max-h-20 overflow-y-auto">{m.payload}</pre>
            </div>
          ))}
        </div>
      )}

      {/* ─── NETWORK ─────────────────────────────────────────────────── */}
      {tab === 'network' && (
        <div className="flex flex-col flex-1 overflow-hidden">
          <div className="flex-shrink-0 grid text-[9px] text-white/30 uppercase tracking-widest px-3 py-1.5 border-b border-white/10 bg-[#0a0a0a]"
            style={{ gridTemplateColumns: '48px 24px 1fr 44px 52px 60px' }}>
            <span>Status</span><span>Meth</span><span>URL</span><span>Type</span><span>Size</span><span className="text-right">Time</span>
          </div>
          <div className="flex-1 overflow-y-auto">
            {nets.length === 0 && (
              <p className="text-white/20 uppercase tracking-widest text-center py-8 text-[10px]">No requests captured yet</p>
            )}
            {[...nets].reverse().map(n => (
              <div key={n.id} className="grid text-[10px] px-3 py-1.5 border-b border-white/[0.03] hover:bg-white/[0.02] items-center"
                style={{ gridTemplateColumns: '48px 24px 1fr 44px 52px 60px' }}>
                <span className={`font-bold ${
                  n.status === 'ERR' || (typeof n.status === 'number' && n.status >= 400) ? 'text-cadmium-red' :
                  n.status === '…' ? 'text-white/30' :
                  (typeof n.status === 'number' && n.status >= 300) ? 'text-yellow-400' : 'text-green-400'
                }`}>{n.status}</span>
                <span className="text-white/30 text-[9px]">{n.method.slice(0, 4)}</span>
                <span className="text-white/60 truncate">{n.url}</span>
                <span className="text-white/30">{n.type}</span>
                <span className="text-white/30">{n.size}</span>
                <span className="text-white/30 text-right tabular-nums">{n.dur}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ─── STORAGE ─────────────────────────────────────────────────── */}
      {tab === 'storage' && (
        <div className="flex flex-col flex-1 overflow-hidden">
          <div className="flex-shrink-0 flex border-b border-white/10">
            {(['local', 'session', 'cookies'] as StorageTab[]).map(s => (
              <button
                key={s}
                onClick={() => setStoreTab(s)}
                className={`text-[9px] uppercase tracking-widest px-4 py-2 border-b-2 transition-all ${
                  storeTab === s ? 'text-white border-cadmium-red' : 'text-white/30 border-transparent hover:text-white/60'
                }`}
              >
                {s === 'local' ? 'localStorage' : s === 'session' ? 'sessionStorage' : 'Cookies'}
              </button>
            ))}
          </div>
          
          <div className="flex-1 overflow-y-auto">
            {storeData.length === 0 && (
              <p className="text-white/20 uppercase tracking-widest text-center py-8 text-[10px]">No items</p>
            )}
            {storeData.length > 0 && (
              <>
                <div className="grid text-[9px] text-white/30 uppercase tracking-widest px-3 py-1.5 border-b border-white/10 bg-[#0a0a0a]"
                  style={{ gridTemplateColumns: '1fr 1fr' }}>
                  <span>Key</span><span>Value</span>
                </div>
                {storeData.map(([k, v], i) => (
                  <div key={i} className="grid text-[10px] px-3 py-1.5 border-b border-white/[0.03] hover:bg-white/[0.02]"
                    style={{ gridTemplateColumns: '1fr 1fr' }}>
                    <span className="text-cadmium-red/80 truncate pr-4" title={k}>{k}</span>
                    <span className="text-white/50 truncate" title={v}>{v}</span>
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
      )}

      {/* ─── OPFS BROWSER ────────────────────────────────────────────── */}
      {tab === 'opfs' && (
        <div className="flex flex-col flex-1 overflow-hidden">
          {/* Breadcrumbs */}
          <div className="flex items-center gap-2 px-3 py-1.5 border-b border-white/10 bg-[#0a0a0a] text-[10px]">
            <span className="text-white/40">Path:</span>
            <button 
              onClick={() => { setOpfsStack([]); loadOpfsDir(); }} 
              className="text-cadmium-red hover:underline transition-all"
            >
              /root
            </button>
            {opfsStack.map((step, i) => (
              <React.Fragment key={i}>
                <span className="text-white/50">/</span>
                <span className="text-white/80">{step.name}</span>
              </React.Fragment>
            ))}
          </div>
          
          {/* Table view */}
          <div className="flex-1 overflow-y-auto">
            <table className="w-full text-[11px] text-left border-collapse">
              <thead className="sticky top-0 bg-[#0a0a0a] text-white/30 uppercase text-[9px]">
                <tr>
                  <th className="px-3 py-2 font-normal">Name</th>
                  <th className="px-3 py-2 font-normal text-right">Size</th>
                </tr>
              </thead>
              <tbody>
                {/* UP ONE LEVEL OPTION */}
                {opfsStack.length > 0 && (
                  <tr 
                    onClick={popOpfsDir}
                    className="hover:bg-white/5 cursor-pointer border-b border-white/[0.03] text-cadmium-red/80 transition-colors"
                  >
                    <td className="px-3 py-1.5 flex items-center gap-2 italic">
                      <ArrowUp size={12} /> ../ [Parent Directory]
                    </td>
                    <td className="px-3 py-1.5 text-right">-</td>
                  </tr>
                )}

                {/* FILE/FOLDER LIST */}
                {opfsEntries.length === 0 && opfsStack.length === 0 && (
                  <tr>
                    <td colSpan={2}>
                      <p className="text-white/20 uppercase tracking-widest text-center py-8 text-[10px]">Directory is empty</p>
                    </td>
                  </tr>
                )}

                {opfsEntries.map((ent, i) => (
                  <tr 
                    key={i} 
                    onClick={() => ent.kind === 'directory' ? enterOpfsDir(ent.name, ent.handle) : dumpOpfsFile(ent.handle)}
                    className="hover:bg-white/10 cursor-pointer border-b border-white/[0.03] group transition-colors"
                    title={ent.kind === 'file' ? 'Click to dump contents to console' : 'Click to enter folder'}
                  >
                    <td className="px-3 py-1.5 flex items-center gap-2">
                      {ent.kind === 'directory' ? <Folder size={13} className="text-blue-400" /> : <File size={13} className="opacity-40 text-white" />}
                      <span className={ent.kind === 'directory' ? "text-white/90" : "text-white/60"}>
                        {ent.name}{ent.kind === 'directory' && '/'}
                      </span>
                    </td>
                    <td className="px-3 py-1.5 text-right opacity-40 tabular-nums">
                      {ent.kind === 'file' ? (ent.size !== undefined ? formatBytes(ent.size) : '0 B') : '--'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
