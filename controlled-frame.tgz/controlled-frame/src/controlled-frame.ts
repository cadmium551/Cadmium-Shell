// Types and feature detection for Chrome's Controlled Frame API (IWA-only).
// Spec: https://wicg.github.io/controlled-frame/

export interface WebRequestInterceptor extends EventTarget {}

export interface ControlledFrameElement extends HTMLElement {
  src: string;
  partition: string;
  readonly contentWindow: WindowProxy | null;
  readonly request: {
    createWebRequestInterceptor(options: {
      urlPatterns: string[];
      blocking?: boolean;
      includeHeaders?: 'none' | 'cors' | 'all';
      resourceTypes?: string[];
    }): WebRequestInterceptor;
  };
  executeScript(details: { code?: string; file?: string }): Promise<unknown>;
  insertCSS(details: { code?: string; file?: string }): Promise<void>;
  clearData(options?: { since?: number }, types?: Record<string, boolean>): Promise<void>;
  setAudioMuted(mute: boolean): void;
  reload(): void;
  stop(): void;
  back(): Promise<boolean>;
  forward(): Promise<boolean>;
  print(): void;
}

export const controlledFrameSupported = (): boolean =>
  typeof window !== 'undefined' && 'HTMLControlledFrameElement' in window;
