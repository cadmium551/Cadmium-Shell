import { serveConnection, hostLabelFor, partitionFor } from '../src/GameServer.ts';

const files: Record<string, File> = {
  '/index.html': new File(['<html>hi</html>'], 'index.html', { lastModified: 1700000000000 }),
  '/Build/game.data.br': new File([new Uint8Array([1,2,3,4,5,6,7,8,9,10])], 'game.data.br'),
  '/Build/game.wasm': new File([new Uint8Array(100).fill(7)], 'game.wasm'),
  '/empty.txt': new File([], 'empty.txt'),
};
const resolve = async (host: string, p: string) => (host.startsWith('ok-') ? files[p === '/' ? '/index.html' : p] ?? null : null);

function pipe() {
  const c2s = new TransformStream<Uint8Array>(); const s2c = new TransformStream<Uint8Array>();
  const done = serveConnection(c2s.readable, s2c.writable, resolve, {});
  const w = c2s.writable.getWriter(); const r = s2c.readable.getReader();
  let buf = new Uint8Array(0);
  const enc = new TextEncoder(), dec = new TextDecoder();
  const pull = async () => { const { value, done } = await r.read(); if (done) return false; const n = new Uint8Array(buf.length + value.length); n.set(buf); n.set(value, buf.length); buf = n; return true; };
  const response = async (isHead = false) => {
    for (;;) {
      const i = dec.decode(buf).indexOf('\r\n\r\n');
      if (i >= 0) {
        const head = dec.decode(buf).slice(0, i); const hlen = enc.encode(head).length + 4;
        const m = /content-length: (\d+)/i.exec(head); const len = m ? +m[1] : 0;
        while (!isHead && buf.length < hlen + len) { if (!(await pull())) break; }
        const body = isHead ? new Uint8Array(0) : buf.slice(hlen, hlen + len); buf = buf.slice(isHead ? hlen : hlen + len);
        return { head, body };
      }
      if (!(await pull())) return { head: '', body: new Uint8Array(0) };
    }
  };
  const send = (raw: string) => w.write(enc.encode(raw));
  return { send, response, close: () => w.close(), done };
}
let failures = 0;
const check = (name: string, ok: boolean, extra = '') => { console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  ' + extra}`); if (!ok) failures++; };

const H = 'Host: ok-game.localhost:47831\r\n';
{
  const c = pipe();
  await c.send(`GET /index.html HTTP/1.1\r\n${H}\r\n`);
  let r = await c.response();
  check('200 html + type + length', r.head.startsWith('HTTP/1.1 200') && /Content-Type: text\/html/.test(r.head) && /Content-Length: 15/.test(r.head), r.head);
  check('html body', new TextDecoder().decode(r.body) === '<html>hi</html>');
  check('CORS + CORP headers', /Access-Control-Allow-Origin: \*/.test(r.head) && /Cross-Origin-Resource-Policy: cross-origin/.test(r.head));
  check('no COEP by default', !/Cross-Origin-Embedder-Policy/.test(r.head));
  // keep-alive: second request on same connection
  await c.send(`GET / HTTP/1.1\r\n${H}\r\n`);
  r = await c.response();
  check('keep-alive second request, "/" -> index.html', r.head.startsWith('HTTP/1.1 200') && new TextDecoder().decode(r.body) === '<html>hi</html>', r.head);
  await c.send(`GET /Build/game.data.br HTTP/1.1\r\n${H}Range: bytes=2-5\r\n\r\n`);
  r = await c.response();
  check('206 range', r.head.startsWith('HTTP/1.1 206') && /Content-Range: bytes 2-5\/10/.test(r.head) && Array.from(r.body).join() === '3,4,5,6', r.head + ' ' + Array.from(r.body));
  check('.br -> Content-Encoding br', /Content-Encoding: br/.test(r.head));
  await c.send(`GET /Build/game.data.br HTTP/1.1\r\n${H}Range: bytes=-3\r\n\r\n`);
  r = await c.response();
  check('suffix range', r.head.startsWith('HTTP/1.1 206') && Array.from(r.body).join() === '8,9,10', r.head);
  await c.send(`GET /Build/game.data.br HTTP/1.1\r\n${H}Range: bytes=50-60\r\n\r\n`);
  r = await c.response();
  check('416 out of range', r.head.startsWith('HTTP/1.1 416') && /Content-Range: bytes \*\/10/.test(r.head), r.head);
  await c.send(`GET /Build/game.wasm HTTP/1.1\r\n${H}\r\n`);
  r = await c.response();
  check('wasm type', /Content-Type: application\/wasm/.test(r.head) && r.body.length === 100);
  await c.send(`GET /empty.txt HTTP/1.1\r\n${H}\r\n`);
  r = await c.response();
  check('empty file', r.head.startsWith('HTTP/1.1 200') && /Content-Length: 0/.test(r.head));
  await c.send(`GET /nope.js HTTP/1.1\r\n${H}\r\n`);
  r = await c.response();
  check('404', r.head.startsWith('HTTP/1.1 404'), r.head);
  await c.send(`GET /a%2f..%2f..%2fetc HTTP/1.1\r\n${H}\r\n`);
  r = await c.response();
  check('encoded-slash traversal rejected (400)', r.head.startsWith('HTTP/1.1 400'), r.head);
  await c.send(`GET /a/%2e%2e/%2e%2e/etc HTTP/1.1\r\n${H}\r\n`);
  r = await c.response();
  check('%2e%2e is normalised by URL parser, stays inside root (404)', r.head.startsWith('HTTP/1.1 404') && /Not found: \/etc/.test(new TextDecoder().decode(r.body)), r.head + new TextDecoder().decode(r.body));
  await c.send(`GET /index.html HTTP/1.1\r\nHost: unknown.localhost:47831\r\n\r\n`);
  r = await c.response();
  check('unknown game host -> 404', r.head.startsWith('HTTP/1.1 404'), r.head);
  await c.send(`GET /index.html HTTP/1.1\r\n${H}Connection: close\r\n\r\n`);
  r = await c.response();
  check('Connection: close honoured', /Connection: close/.test(r.head));
  await c.done;
  check('server ends connection after close', true);
}
{
  const c = pipe();
  await c.send(`HEAD /index.html HTTP/1.1\r\n${H}Connection: close\r\n\r\n`);
  // HEAD: headers only, no body — read raw until stream ends
  const { head } = await c.response(true);
  check('HEAD has length but no body', head.startsWith('HTTP/1.1 200') && /Content-Length: 15/.test(head));
  await c.done;
}
{
  const c = pipe();
  await c.send(`POST /index.html HTTP/1.1\r\n${H}Content-Length: 3\r\n\r\nabc`);
  const r = await c.response();
  check('POST -> 405', r.head.startsWith('HTTP/1.1 405') && /Allow: GET, HEAD/.test(r.head), r.head);
  await c.done;
}
{
  // request head split across chunks
  const c = pipe();
  await c.send('GET /index.ht'); await c.send(`ml HTTP/1.1\r\n${H}Conn`); await c.send('ection: close\r\n\r\n');
  const r = await c.response();
  check('request split across chunks', r.head.startsWith('HTTP/1.1 200'), r.head);
  await c.done;
}
check('hostLabelFor is DNS-safe', /^[a-z0-9-]+$/.test(hostLabelFor('Hollow Knight (v1)_x.html')) && hostLabelFor('a_b') !== hostLabelFor('ab'), hostLabelFor('Hollow Knight (v1)_x.html'));
check('partition is alphanumeric + persist:', /^persist:[a-z0-9]+$/.test(partitionFor('tweakerhk_html')), partitionFor('tweakerhk_html'));
console.log(failures ? `\n${failures} FAILED` : '\nALL PASSED');
process.exit(failures ? 1 : 0);
